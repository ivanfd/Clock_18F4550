
#ifndef SI7021_H
#define	SI7021_H

#include <xc.h> // include processor files - each processor file is guarded.  
#include "i2c.h"
#include "common.h"

/*!
 *  I2C ������
 */
#define SI7021_ADDRESS_W 0x80 // 0x40 << 1
#define SI7021_ADDRESS_R 0x81 // (0x40 << 1) | 1

#define SI7021_MEASRH_HOLD_CMD 0xE5 // Measure Relative Humidity, Hold Master Mode
#define SI7021_MEASRH_NOHOLD_CMD 0xF5 // Measure Relative Humidity, No Hold Master Mode 
#define SI7021_MEASTEMP_HOLD_CMD 0xE3 // Measure Temperature, Hold Master Mode
#define SI7021_MEASTEMP_NOHOLD_CMD 0xF3 // Measure Temperature, No Hold Master Mode 
#define SI7021_READPREVTEMP_CMD 0xE0 // Read Temperature Value from Previous RH Measurement

#define SI7021_RESET_CMD 0xFE           // Reset Command 
#define SI7021_WRITERHT_REG_CMD 0xE6    // Write RH/T User Register 1 
#define SI7021_READRHT_REG_CMD 0xE7     // Read RH/T User Register 1 
#define SI7021_WRITEHEATER_REG_CMD 0x51 // Write Heater Control Register 
#define SI7021_READHEATER_REG_CMD 0x11  // Read Heater Control Register 
#define SI7021_REG_HTRE_BIT 0x02        // Control Register Heater Bit 
#define SI7021_ID1_CMD 0xFA0F           // Read Electronic ID 1st Byte 
#define SI7021_ID2_CMD 0xFCC9           // Read Electronic ID 2nd Byte 
#define SI7021_FIRMVERS_CMD 0x84B8      // Read Firmware Revision 


void si7021_reset(void);
uint8_t si7021_init(void);
void si7021_Write(uint8_t address, uint8_t value);
uint8_t si7021_Read(uint8_t address);

#endif	/* XC_HEADER_TEMPLATE_H */

